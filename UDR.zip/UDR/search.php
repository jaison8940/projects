<?php include_once 'config/init.php'; ?>

<?php 

	$job = new Job;

	if(isset($_SESSION['logged_in_UDR']) && $_SESSION['logged_in_UDR']){

		if(isset($_POST['certification_name']))
		{
			$res = $job->getCertDetails($_POST['certification_name'],$_SESSION['email']);
			;
			if(empty($res))
			{
				$output = '<ul class="list-group">
				<li class="list-group-item"><strong class="strong">Not Found</strong></li> 
				</ul>
				';
				
				echo $output;
			}
			else
			{
				
				$output = '<ul class="list-group">';
				foreach($res as $certification_details){
			    	
			    	$output .= '<li class="list-group-item"><strong class="strong">EMPLOYEE NAME:</strong>'.$certification_details->employee_name.'</li>';

					$output .= '<li class="list-group-item"><strong class="strong">EMAIL:</strong>'.$certification_details->email.'</li>';


					$output .= '<li class="list-group-item"><strong class="strong">CSP:</strong>'.$certification_details->csp.'</li>';
					$output .= '<li class="list-group-item"><strong class="strong">CERTIFICATION LEVEL:</strong>'.$certification_details->certification_level.'</li>';
					
					$output .= '<li class="list-group-item"><strong class="strong">CERTIFICATION NAME:</strong>'.$certification_details->certification_name.'</li>';
					$output .= '<li class="list-group-item"><strong class="strong">CERTIFICATION ID:</strong>'.$certification_details->certification_id.'</li>';
					$output .= '<li class="list-group-item"><strong class="strong">DATE OF CERTIFICATION:</strong>'.date("d-m-Y", strtotime($certification_details->date_of_certification)).'</li>';
					$output .= '<li class="list-group-item"><strong class="strong">EXPIRY DATE:</strong>'.date("d-m-Y", strtotime($certification_details->expiry_date)).'</li>';
					$output .= '<li class="list-group-item"><strong class="strong">VALIDITY:</strong>'.$certification_details->validity.'</li>';
			    }
			    $output .= '</ul>';
				echo $output;
			}

		}
		else if(isset($_POST['csp_id']))
		{
			$result = $job->getCsp_names($_POST['csp_id']);
			$output .= '<option value="">Choose Certification</option>';
		    foreach($result as $row){
		    	$output .= '<option value="'.$row->certification_name.'">'.$row->certification_name.'</option>';
		    }

		    echo $output;

		}
		else
		{
			$template = new Template('templates/search-page.php');
			$template->csps = $job->get_csps();
			echo $template;
		}

		

	}
	else{
		
		$template = new Template('templates/login-page.php');
		echo $template;

	}





?>