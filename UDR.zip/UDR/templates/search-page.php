<?php include 'includes/header.php'; ?>
<style type="text/css">
	.strong{
		font-weight: 900;
		display:inline-block;
		text-align: left;
		width: 200px;
	}
</style>
<div style="margin-top: 16px;" class="jumbotron w-100 p-3" >
        <h1 style="text-align: center;">Search your certification details!</h1>
        <form id="search">
        	<div style="margin: auto; border: 1px solid black; width: 50%;">
        		<select id="csp" name="csp" class="form-control">
	            	<option value="0">Choose Csp</option>
	            	<?php foreach ($csps as $csp): ?>
			            <option value="<?php echo $csp->id; ?>"><?php echo $csp->csp_name; ?></option>
			        <?php endforeach; ?>	            
	          	</select>        		
        	</div>
        	<br>
        	<div style="margin: auto; border: 1px solid black; width: 50%;">
        		<select id="certifications_names" name="certifications_names" class="form-control">
	            	<option value="0">Choose Certification</option>		            	       
	          	</select>        		
        	</div>
        	
            <br>
	        <div style="text-align: center;">
	          <input style="padding: 20px;" type="submit" class="btn btn-lg btn-success" value="Search">
	        </div>
	       
        </form>
</div>

<div id="output"></div>

	
<br>

<script>
    
    $(document).ready(function(){


      $('#csp').change(function(){
      	
        var id = $(this).val();
	        $.ajax({
	          url: "search.php",
	          method: "POST",
	          data: {
	            csp_id: id
	            },
	          success: function( result ) {

	            $( "#certifications_names" ).html(result);
	            console.log(result);
	            
	          }
	        });
        }); 

      $('form').submit(function(){
        var name = $('#certifications_names').val();

        $( "#sample" ).text(name);
	        $.ajax({
	          url: "search.php",
	          method: "POST",
	          data: {
	            certification_name: name
	            },
	          success: function( result ) {

	            $( "#output" ).html(result);
	            console.log(result);
	           
	          }
	        });
	       
	       return false;
        }); 

    });


</script>

<?php include 'includes/footer.php'; ?>