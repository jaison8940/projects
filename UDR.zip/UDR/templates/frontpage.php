<?php include 'includes/header.php'; ?>
<div class="jumbotron container">

    <button class="btn btn-primary" >Welcome to user details registration!</button><br><br>
    
</div>

<?php include 'includes/footer.php'; ?>