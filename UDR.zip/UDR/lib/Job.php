<?php 
	class Job{
		private $db;

		public function __construct(){
			$this->db = new Database;
		}
		

		public function auth($data){
			$this->db->query("SELECT count(*) as c FROM user_login_details WHERE email = :email");

			$this->db->bind(':email',$data['email']);
			// $this->db->bind(':password',$data['password']);
			$res = $this->db->single();

			if($res->c)
			{
				return false;
			}
			else{
				return true;

			}
			


		}

		public function enter_user_creds($data){
			

			$this->db->query("INSERT INTO user_login_details (email, password) VALUES (:email, :password)");

			$this->db->bind(':email',$data['email']);
			$this->db->bind(':password',$data['password']);


			if($this->db->execute()){
				return true;
			}
			else {
				return false;
			}
		

		}

		public function auth2($data){
			$this->db->query("SELECT count(*) as c FROM user_login_details WHERE email = :email and password = :password");

			$this->db->bind(':email',$data['email']);
			$this->db->bind(':password',$data['password']);
			$res = $this->db->single();

			if($res->c == 1)
			{
				return 1;
			}
			else
			{
				$this->db->query("SELECT count(*) as c FROM user_login_details WHERE email = :email");
				$this->db->bind(':email',$data['email']);
				$res = $this->db->single();
				if($res->c == 1)
				{
					return 2;
				}
				else {
					return 3;

				}

				

			}
		}

		public function enter_cert_details($data){
			

			$this->db->query("INSERT INTO certification_details (employee_name, email, csp, certification_level, certification_name, certification_id, date_of_certification, expiry_date, validity, user_email) VALUES (:employee_name, :email, :csp, :certification_level, :certification_name, :certification_id, :date_of_certification, :expiry_date, :validity, :user_email)");

			$this->db->bind(':employee_name',$data['employee_name']);
			$this->db->bind(':email',$data['email']);
			$this->db->bind(':csp',$data['csp']);
			$this->db->bind(':certification_level',$data['certification_level']);
			$this->db->bind(':certification_name',$data['certification_name']);
			$this->db->bind(':certification_id',$data['certification_id']);
			$this->db->bind(':date_of_certification',$data['date_of_certification']);
			$this->db->bind(':expiry_date',$data['expiry_date']);
			$this->db->bind(':validity',$data['validity']);
			$this->db->bind(':user_email',$data['user_email']);
			


			if($this->db->execute()){
				return true;
			}
			else {
				return false;
			}
		

		}

		public function get_csps(){
			$this->db->query("SELECT * FROM csp");

			// $this->db->bind(':email',$data['email']);
			// $this->db->bind(':password',$data['password']);
			$res = $this->db->resultSet();

			return $res;
			


		}

		public function getCsp_names($data){
			$this->db->query("SELECT * FROM certification_names WHERE csp_id = :csp_id");
			$this->db->bind(':csp_id',$data['csp_id']);

			
			$res = $this->db->resultSet();

			return $res;
			


		}

		public function getCertDetails($cname,$email){
			$this->db->query("SELECT * FROM certification_details WHERE certification_name = :certification_name and user_email = :user_email");
			$this->db->bind(':certification_name',$cname);
			$this->db->bind(':user_email',$email);

			
			$res = $this->db->resultSet();

			return $res;
			


		}

		public function authenticate_certification($data){
			$this->db->query("SELECT count(*) as c FROM certification_details WHERE certification_name = :certification_name and user_email = :user_email");

			$this->db->bind(':certification_name',$data['certification_name']);
			$this->db->bind(':user_email',$data['user_email']);
			$res = $this->db->single();

			if($res->c)
			{
				return true;
			}
			else{
				return false;

			}
			


		}

		

	}