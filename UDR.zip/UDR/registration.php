<?php include_once 'config/init.php'; ?>

<?php 

	use PHPMailer\PHPMailer\PHPMailer;
	require_once 'PHPMailer-master/src/PHPMailer.php';
	require_once 'PHPMailer-master/src/SMTP.php';
	require_once 'PHPMailer-master/src/Exception.php';

	$job = new Job;
	
	
	if(isset($_SESSION['logged_in_UDR']) && $_SESSION['logged_in_UDR']){
		 	
		
		
		if(isset($_POST['submit']))
		{
			$data = array();
			$data['employee_name'] = $_POST['employee_name'];
			$data['email'] = $_POST['email'];
			$data['csp'] = $_POST['csp'];
			$data['certification_level'] = $_POST['certification_level'];
			$data['certification_name'] = $_POST['certification_name'];
			$data['certification_id'] = $_POST['certification_id'];
			$data['date_of_certification'] = $_POST['date_of_certification'];
			$data['expiry_date'] = $_POST['expiry_date'];
			$data['validity'] = $_POST['validity'];
			$data['user_email'] = $_SESSION['email'];

			if($job->authenticate_certification($data))
			{
				reDirect("registration.php","Already Registered!","error");


			}

			if($job->enter_cert_details($data))
			{
				
			    $sender = 'udr.notification@gmail.com';
				$senderName = 'UDR';

		// Replace recipient@example.com with a "To" address. If your account
		// is still in the sandbox, this address must be verified.
				$recipient = $_SESSION['email'];

		// Replace smtp_username with your Amazon SES SMTP user name.
				$usernameSmtp = 'AKIA6Q7FZIZJZLYHIRXP';

		// Replace smtp_password with your Amazon SES SMTP password.
				$passwordSmtp = 'BLm7O9L66nR1Px547gPzfa7U4fsaqOtlj5ZievocYrK5';

		// Specify a configuration set. If you do not want to use a configuration
		// set, comment or remove the next line.
		// $configurationSet = 'ConfigSet';

		// If you're using Amazon SES in a region other than US West (Oregon),
		// replace email-smtp.us-west-2.amazonaws.com with the Amazon SES SMTP
		// endpoint in the appropriate region.
				$host = 'email-smtp.us-east-1.amazonaws.com';
				$port = 587;

		// The subject line of the email
				$subject = 'Success!';

		// The plain-text body of the email
				$bodyText =  "Email Test\r\nThis email was sent through the Amazon SES SMTP interface using the PHPMailer class.";

		// The HTML-formatted body of the email
				$bodyHtml = '<h1>Your certification details are registered successfully!</h1>
		    <p>Please <a href="ec2-34-205-141-53.compute-1.amazonaws.com/search.php">click here</a> to search to details</p>';

				$mail = new PHPMailer(true);

				try {
		    // Specify the SMTP settings.
		    		$mail->isSMTP();
		    		$mail->setFrom($sender, $senderName);
		    		$mail->Username   = $usernameSmtp;
		    		$mail->Password   = $passwordSmtp;
		    		$mail->Host       = $host;
		    		$mail->Port       = $port;
		    		$mail->SMTPAuth   = true;
		    		$mail->SMTPSecure = 'tls';
		    // $mail->addCustomHeader('X-SES-CONFIGURATION-SET', $configurationSet);

		    // Specify the message recipients.
		    		$mail->addAddress($recipient);
		    // You can also add CC, BCC, and additional To recipients here.

		    // Specify the content of the message.
		    		$mail->isHTML(true);
		    		$mail->Subject    = $subject;
		    		$mail->Body       = $bodyHtml;
		    		$mail->AltBody    = $bodyText;
		    		$mail->Send();
		    		echo "Email sent!" , PHP_EOL;
				} catch (phpmailerException $e) {
		    		echo "An error occurred. {$e->errorMessage()}", PHP_EOL; //Catch errors from PHPMailer.
				} catch (Exception $e) {
		    		echo "Email not sent. {$mail->ErrorInfo}", PHP_EOL; //Catch errors from Amazon SES.
				}
				reDirect("registration.php","Registered Successfully!","success");
			}
			else 
			{
				reDirect("registration.php","Something went wrong!","error");
			}
			
		}
		else 
		{
			$template = new Template('templates/registration-page.php');
			echo $template;
		}
	}
	else{
		
		$template = new Template('templates/login-page.php');
		echo $template;

	}





?>