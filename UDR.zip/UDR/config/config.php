<?php 


define("DB_HOST","database-1.cby76krperom.us-east-1.rds.amazonaws.com");
define("DB_USER","admin");
define("DB_PASS","12345678");
define("DB_NAME","udr");

define("SITE_TITLE","UDR");