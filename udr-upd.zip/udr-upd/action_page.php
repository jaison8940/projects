<?php include_once 'config/init.php'; ?>

<?php

$job = new Job;
use PHPMailer\PHPMailer\PHPMailer;
require_once 'PHPMailer-master/src/PHPMailer.php';
require_once 'PHPMailer-master/src/SMTP.php';
require_once 'PHPMailer-master/src/Exception.php';

if(isset($_SESSION['logged_in_UDR']) && $_SESSION['logged_in_UDR'])
{

if(isset($_POST['submit']))
{

$name = $_POST['name'];
$visitor_email = $_POST['email'];
$message = $_POST['comment'];

$sender = 'Sender mail address';
$senderName = 'Sender name';

// Replace recipient@example.com with a "To" address. If your account
// is still in the sandbox, this address must be verified.
$recipient1 = 'email address 1';
$recipient2 = 'email address 2';
$recipient3 = 'email address 3';

// Replace smtp_username with your Amazon SES SMTP user name.
$usernameSmtp = 'SMTP username';

// Replace smtp_password with your Amazon SES SMTP password.
$passwordSmtp = 'SMTP password';

// Specify a configuration set. If you do not want to use a configuration
// set, comment or remove the next line.
// $configurationSet = 'ConfigSet';

// If you're using Amazon SES in a region other than US West (Oregon),
// replace email-smtp.us-west-2.amazonaws.com with the Amazon SES SMTP
// endpoint in the appropriate region.
$host = 'email-smtp.us-east-1.amazonaws.com';
$port = 587;

// The subject line of the email
$subject = 'You Got a New Message!';

// The plain-text body of the email
$bodyText =  "Email Test\r\nThis email was sent through the Amazon SES SMTP interface using the PHPMailer class.";

// The HTML-formatted body of the email
$bodyHtml = "You have received a new message from the user " .$name. "\n".
            "Email address: " .$visitor_email. "\n".
            "Here is the message: " ."\n" .$message;

$mail = new PHPMailer(true);

try {
   // Specify the SMTP settings.
    $mail->isSMTP();
    $mail->setFrom($sender, $senderName);
    $mail->Username   = $usernameSmtp;
    $mail->Password   = $passwordSmtp;
    $mail->Host       = $host;
    $mail->Port       = $port;
    $mail->SMTPAuth   = true;
    $mail->SMTPSecure = 'tls';
   // $mail->addCustomHeader('X-SES-CONFIGURATION-SET', $configurationSet);

   // Specify the message recipients.
    $mail->addAddress($recipient1);
    $mail->addAddress($recipient2);
    $mail->addAddress($recipient3);
   // You can also add CC, BCC, and additional To recipients here.

   // Specify the content of the message.
    $mail->isHTML(true);
    $mail->Subject    = $subject;
    $mail->Body       = $bodyHtml;
    $mail->AltBody    = $bodyText;
    $mail->Send();
    echo "Email sent!" , PHP_EOL;
}
catch (phpmailerException $e) {
    echo "An error occurred. {$e->errorMessage()}", PHP_EOL; 
    reDirect('contact.php','Oops could not send your message!', 'error');
    //Catch errors from PHPMailer.
}
catch (Exception $e) {
    echo "Email not sent. {$mail->ErrorInfo}", PHP_EOL; 
    reDirect('contact.php','Oops could not send your message!', 'error');
    //Catch errors from Amazon SES.
}

reDirect('contact.php','Your Message Sent Successfully!', 'success');


}
else
{
$template = new Template('templates/contact-page.php');
echo $template;
}







}
else{

$template = new Template('templates/login-page.php');
echo $template;

}





?>