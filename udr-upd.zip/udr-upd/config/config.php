<?php 


define("DB_HOST","Your DB host name");
define("DB_USER","Your DB user name");
define("DB_PASS","Your DB password");
define("DB_NAME","Your DB name");

define("SITE_TITLE","UDR");

?>