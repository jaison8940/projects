<!--
<div class="jumbotron container">

    <button class="btn btn-primary" >Welcome to user details registration!</button><br><br>
    
</div>
-->
<?php include 'includes/header.php'; ?>



<article class="certificates">
  <h2 style= "color:blue; font-size:25px;">Certification Details</h2>
    <marquee behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
    <a href="https://aws.amazon.com/certification/certified-solutions-architect-associate/" target="_blank">AWS Certified Solution Architect-Associate</a></br>
    <a href="https://aws.amazon.com/certification/certified-developer-associate/" target="_blank">AWS Certified Developer-Associate</a></br>
    <a href="https://aws.amazon.com/certification/certified-sysops-admin-associate/" target="_blank">AWS Certified SysOps Administrator-Associate</a></br>
    <a href="https://aws.amazon.com/certification/certified-solutions-architect-professional/" target="_blank">AWS Certified Solution Architect-Professional</a></br>
    <a href="https://cloud.google.com/certification/cloud-architect" target="_blank">Professional Cloud Architect</a></br>
    <a href="https://cloud.google.com/certification/cloud-developer" target="_blank">Professional Cloud Developer</a></br>
    <a href="https://cloud.google.com/certification/data-engineer" target="_blank">Professional Data Engineer</a></br>
    <a href="https://docs.microsoft.com/en-us/learn/certifications/azure-administrator/" target="_blank">Azure Administrator-Associate</a></br>
    <a href="https://docs.microsoft.com/en-us/learn/certifications/azure-developer/" target="_blank">Azure Developer-Associate</a></br>
    </marquee>
  
  </article>
 
   
   <aside>
   <img class="mySlides" src="images\cloud.png" alt="image not found" style="height:450px;width:500px;padding:0">
   <img class="mySlides" src="images\gcp.png" alt="image not found" style="height:450px;width:500px;padding:0">
   <img class="mySlides" src="images\aws.png" alt="image not found" style="height:450px;width:500px;padding:0">
   <img class="mySlides" src="images\azure.png" alt="image not found" style="height:450px;width:500px;padding:0">
<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2000); 
}
</script>
   </aside>

