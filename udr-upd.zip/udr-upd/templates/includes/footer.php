			<footer class="footer">
        <p>&copy; 2021 UDR, Inc.</p>
      </footer>

    </div> <!-- /container -->
		</body>
</html>